<#
    .DESCRIPTION
        An example runbook which working as DNS FailOver using the Run As Account (Service Principal)

    .NOTES
        AUTHOR: N. Tzelvenzis
        LASTEDIT: Apr 21, 2018
#>

$ResourceGroupName = Get-AutomationVariable -Name 'ResourceGroupName'
$ZoneName = Get-AutomationVariable -Name 'ZoneName'

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name 'AzureRunAsConnection'

    #"Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

# Read TXT Records to find the failover services
$txtRecords = Get-AzureRmDnsRecordSet -Name "failover" -RecordType TXT -ResourceGroupName $ResourceGroupName -ZoneName $ZoneName | Select-Object -ExpandProperty Records

Foreach ($record in $txtRecords)
{
    # Convert text record to JSON object
	$service = ConvertFrom-JSON $record
    # Extract the primary address as address to check
	$checkAddress = $service.primary | Select-Object -First 1 -ExpandProperty Ipv4Address
	
	# Create a new TCP Client to check the port
    $t = New-Object Net.Sockets.TcpClient
    # Try to connect on address
	try
	{
		$t.Connect($checkAddress,$service.port)
	} catch {}
    #If connected the primary address is up
	if($t.Connected)
	{
        # Now close connection to release resources
		$t.Close()
        # New address is the primary
		$NewAddresses = $service.primary | Select-Object -ExpandProperty Ipv4Address
		# Echo a message to output
        "Port " + $service.port + " is opened for service " + $service.service + " on address " + $checkAddress
	}
	else
	{	
        # Opps connection cannot be establisted so the backup address will be used
		$NewAddresses = $service.backup | Select-Object -ExpandProperty Ipv4Address
		# Echo a message to output
		"Port " + $service.port + " is closed for service " + $service.service + " on address " + $checkAddress
	} 
    # Now let's update the correct record
	$DNSRecordSet = Get-AzureRmDnsRecordSet -ResourceGroupName $ResourceGroupName -ZoneName $ZoneName -Name $service.service -RecordType A
	if (-not ($($DNSRecordSet.Records | Select-Object -First 1 -ExpandProperty Ipv4Address) -eq $($NewAddress | Select-Object -First 1)))
	{
		$DNSRecordSet.Records = @()
		Foreach($NewAddress in $NewAddresses) {
			$addr = Add-AzureRmDnsRecordConfig -RecordSet $DNSRecordSet -Ipv4Address $NewAddress
            "Switch service " + $service.service + " to address " + $addr.Records
		}
		$mute = Set-AzureRmDnsRecordSet -RecordSet $DNSRecordSet
	}
}